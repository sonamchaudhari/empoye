﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EDS.Master
{
    public partial class Band : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["empid"] == null)
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtclear();
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO Band (BandCode, BandName) VALUES  (@code,@bandname)", cn);
            cmd.Parameters.AddWithValue("@code", txtbandcode.Text);
            cmd.Parameters.AddWithValue("@bandname", txtbandname.Text);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            GridView1.DataBind();
            txtclear();
           
        }

        public void txtclear()
        {
            txtbandcode.Text = "";
            txtbandname.Text = "";
        }

    }
}
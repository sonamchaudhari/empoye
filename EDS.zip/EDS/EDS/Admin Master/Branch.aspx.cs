﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace EDS.Master
{
    public partial class Branch : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["empid"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            if (Request.QueryString["bid"] != null)
            {
                btnAdd.Visible = false;
                cmd = new SqlCommand("select * from Branch where BranchID=@id", cn);
                cmd.Parameters.AddWithValue("@id", Request.QueryString["bid"]);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                txtBranchCode.Text = dt.Rows[0][0].ToString();
                txtBranchName.Text = dt.Rows[0][1].ToString();
                txtaddress.Text = dt.Rows[0][2].ToString();
                txtcountry.Text = dt.Rows[0][3].ToString();
                txtstate.Text = dt.Rows[0][4].ToString();
                txtcity.Text = dt.Rows[0][5].ToString();
                txtarea.Text = dt.Rows[0][6].ToString();
                txtpin.Text = dt.Rows[0][7].ToString();
                txtcontact.Text = dt.Rows[0][8].ToString();
                txtcontact2.Text = dt.Rows[0][9].ToString();
                txtcontact3.Text = dt.Rows[0][10].ToString();
                txtFax.Text = dt.Rows[0][11].ToString();
                txtemail.Text = dt.Rows[0][12].ToString();
                txtwebsite.Text = dt.Rows[0][13].ToString();
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            
            btnAdd.Visible = true; 
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {

            cmd = new SqlCommand("INSERT INTO Branch (BranchId, BranchName, Address, Country, State, City, Area, PinCode, Contact1, Contact2, Contact3, Fax, EmailID, Website) VALUES   (@id,@name,@address,@country,@state,@city,@area,@pincode,@contact1,@contact2,@contact3,@fax,@emailid,@website)", cn);
            cmd.Parameters.AddWithValue("@id", txtBranchCode.Text);
            cmd.Parameters.AddWithValue("@name", txtBranchName.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@area", txtarea.Text);
            cmd.Parameters.AddWithValue("@state", txtstate.Text);
            cmd.Parameters.AddWithValue("@country", txtcountry.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Parameters.AddWithValue("@pincode", txtpin.Text);
            cmd.Parameters.AddWithValue("@contact1", txtcontact.Text);
            cmd.Parameters.AddWithValue("@contact2", txtcontact2.Text);
            cmd.Parameters.AddWithValue("@contact3", txtcontact3.Text);
            cmd.Parameters.AddWithValue("@fax", txtFax.Text);
            cmd.Parameters.AddWithValue("@emailid", txtemail.Text);
            cmd.Parameters.AddWithValue("@website", txtwebsite.Text);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            txtclear();
            GridView1.DataBind();
             

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("UPDATE  Branch SET  BranchId = @id,  BranchName = @name, Address = @address, Country = @country, State = @state, City = @city, Area = @area, PinCode = @pincode, Contact1 = @contact1, Contact2 = @contact2, Contact3 = @contact3, Fax = @fax, EmailID = @emailid, Website = @website WHERE (BranchId = @bid)", cn);
            cmd.Parameters.AddWithValue("@bid", Request.QueryString["bid"]);
            cmd.Parameters.AddWithValue("@id", txtBranchCode.Text);
            cmd.Parameters.AddWithValue("@name", txtBranchName.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@area", txtarea.Text);
            cmd.Parameters.AddWithValue("@state", txtstate.Text);
            cmd.Parameters.AddWithValue("@country", txtcountry.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Parameters.AddWithValue("@pincode", txtpin.Text);
            cmd.Parameters.AddWithValue("@contact1", txtcontact.Text);
            cmd.Parameters.AddWithValue("@contact2", txtcontact2.Text);
            cmd.Parameters.AddWithValue("@contact3", txtcontact3.Text);
            cmd.Parameters.AddWithValue("@fax", txtFax.Text);
            cmd.Parameters.AddWithValue("@emailid", txtemail.Text);
            cmd.Parameters.AddWithValue("@website", txtwebsite.Text);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        
        }
        public void txtclear()
        {
            txtBranchCode.Text = "";
            txtBranchName.Text = "";
            txtaddress.Text = "";
            txtcountry.Text = "";
            txtstate.Text = "";
            txtcity.Text = "";
            txtarea.Text = "";
            txtpin.Text = "";
            txtcontact.Text = "";
            txtcontact2.Text = "";
            txtcontact3.Text = "";
            txtFax.Text = "";
            txtemail.Text = "";
            txtwebsite.Text = "";
        }

         

    }

}
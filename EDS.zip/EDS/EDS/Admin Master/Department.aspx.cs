﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EDS.Master
{
    public partial class Department : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {

           
                
             
            if (!IsPostBack)
            {
                Empfill();
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        public void Empfill()
        {
            adp = new SqlDataAdapter("Select EmpID,(FName+' '+MName+' '+LName)as Name From EmployeePersonalDetail", cn);
            dt = new DataTable();

            dt.Clear();
            adp.Fill(dt);
            ddHOD.DataSource = dt;
            ddHOD.DataTextField = "Name";
            ddHOD.DataValueField = "EmpID";
            ddHOD.DataBind();
        }
        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtclear();
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO Department (DepartmentId, DepartmentName, HODName) VALUES (@deptid,@deptname,@hodname)", cn);
            cmd.Parameters.AddWithValue("@deptid",txtDepartmentCode.Text);
            cmd.Parameters.AddWithValue("@deptname", txtDepartmentName.Text);
            cmd.Parameters.AddWithValue("@hodname", ddHOD.SelectedValue);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            txtclear();
            GridView1.DataBind();

        }
        public void txtclear()
        {
            txtDepartmentCode.Text = "";
            txtDepartmentName.Text = "";
        }

       

    }
}
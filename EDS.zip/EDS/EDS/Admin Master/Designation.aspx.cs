﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EDS.Master
{
    public partial class Designation : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtclear();
        }

        public void txtclear()
        {
            txtdesignationcode.Text = "";
            txtdesignationname.Text = "";
            
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO Designation (DesignationCode, DesignationName) VALUES    (@code,@name)", cn);
            cmd.Parameters.AddWithValue("@code", txtdesignationcode.Text);
            cmd.Parameters.AddWithValue("@name",txtdesignationname.Text);
            
            cn.Open();
              cmd.ExecuteNonQuery();
            cn.Close();
            txtclear();
            GridView1.DataBind();

        }
    }
}
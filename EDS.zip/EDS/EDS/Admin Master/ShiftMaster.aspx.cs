﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;



namespace EDS.Master
{
    public partial class ShiftMaster : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtclear();
            
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO ShiftMaster (ShiftCode, ShiftName, StartTime, EndTime, EarlyExit, Late, BreakStart, BreakEnd) VALUES   (@shiftcode,@shiftname,@starttime,@endtime,@earlyexit,@late,@breakstart,@breakend)", cn);
            cmd.Parameters.AddWithValue("@shiftcode", txtshiftcode.Text);
            
            cmd.Parameters.AddWithValue("@shiftname", txtshiftname.Text);
            cmd.Parameters.AddWithValue("@starttime",Convert.ToDateTime(txtstarttime.Text));
            cmd.Parameters.AddWithValue("@endtime", Convert.ToDateTime(txtendtime.Text));
            cmd.Parameters.AddWithValue("@earlyexit",Convert.ToDateTime(txtearlyexitbefore.Text));
            cmd.Parameters.AddWithValue("@late",Convert.ToDateTime(txtlateafter.Text));
            cmd.Parameters.AddWithValue("@breakstart", Convert.ToDateTime(txtbreakfrom.Text));
            cmd.Parameters.AddWithValue("@breakend", Convert.ToDateTime(txtbreaktill.Text));
             
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            txtclear();
            GridView1.DataBind();
        }

        public void txtclear()
        {
            txtshiftcode.Text = "";
            txtshiftname.Text = "";
            txtstarttime.Text = "";
            txtendtime.Text = "";
            txtbreakfrom.Text = "";
            txtbreaktill.Text = "";
            txtlateafter.Text = "";
            txtearlyexitbefore.Text = "";
         
        }
    }
}
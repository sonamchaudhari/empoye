﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EDS.Master
{
    public partial class Branch : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp = new SqlDataAdapter();
        DataTable dt = new DataTable();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["id"] != null)
            {

                btnAdd.Visible = false;                              
                
                cn.Open();
                cmd = new SqlCommand("select * from Branch where BranchID=@id", cn);
                cmd.Parameters.AddWithValue("@id", Request.QueryString["id"]);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
                txtBranchCode.Text = dt.Rows[0][0].ToString();
                txtBranchName.Text = dt.Rows[0][1].ToString();
                txtaddress.Text = dt.Rows[0][2].ToString();
                txtcountry.Text = dt.Rows[0][3].ToString();
                txtstate.Text = dt.Rows[0][4].ToString();
                txtcity.Text = dt.Rows[0][5].ToString();
                txtarea.Text = dt.Rows[0][6].ToString();
                txtpin.Text = dt.Rows[0][7].ToString();
                txtcontact1.Text = dt.Rows[0][8].ToString();
                txtcontact2.Text = dt.Rows[0][9].ToString();
                txtcontact3.Text = dt.Rows[0][10].ToString();
                txtFax.Text = dt.Rows[0][11].ToString();
                txtemail.Text = dt.Rows[0][12].ToString();
                txtwebsite.Text = dt.Rows[0][13].ToString();

            }

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtBranchCode.Text = "";
            txtBranchName.Text = "";
            txtaddress.Text = "";
            txtcity.Text = "";
            txtcountry.Text = "";
            txtarea.Text = "";
            txtstate.Text = "";
            txtpin.Text = "";
            txtcontact1.Text = "";
            txtcontact2.Text = "";
            txtcontact3.Text = "";
            txtFax.Text = "";
            txtemail.Text = "";
            txtwebsite.Text = "";
            btnAdd.Visible = true;
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO Branch  (BranchId, BranchName, Address, Country, State, City, Area, PinCode, Contact1, Contact2, Contact3, Fax, EmailID, Website) VALUES  (@branchid,@branchname,@address,@country,@state,@city,@area,@pincode,@contact1,@contact2,@contact3,@fax,@emailid,@website)", cn);
            cmd.Parameters.AddWithValue("@branchid", txtBranchCode.Text);
            cmd.Parameters.AddWithValue("@branchname", txtBranchName.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@state", txtstate.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Parameters.AddWithValue("@area", txtarea);
            cmd.Parameters.AddWithValue("@pincode", txtpin.Text);
            cmd.Parameters.AddWithValue("@contact1", txtcontact1.Text);
            cmd.Parameters.AddWithValue("@contact2", txtcontact2.Text);
            cmd.Parameters.AddWithValue("@contact3", txtcontact3);
            cmd.Parameters.AddWithValue("@fax", txtFax.Text);
            cmd.Parameters.AddWithValue("@emailid", txtemail.Text);
            cmd.Parameters.AddWithValue("@website", txtwebsite.Text);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }


    }
}
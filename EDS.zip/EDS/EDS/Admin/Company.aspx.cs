﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace EDS.Master
{
    public partial class Company : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["cid"] != null)
            {
                btnadd.Visible = false;
                cmd = new SqlCommand("select * from Company where CompanyID=@cid", cn);
                cmd.Parameters.AddWithValue("@cid", Request.QueryString["cid"]);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                txtCompanyCode.Text = dt.Rows[0][0].ToString();
                txtCompanyName.Text = dt.Rows[0][1].ToString();
                txtaddress.Text = dt.Rows[0][2].ToString();
                txtarea.Text = dt.Rows[0][3].ToString();
                txtstate.Text = dt.Rows[0][4].ToString();
                txtcountry.Text = dt.Rows[0][5].ToString();
                txtcity.Text = dt.Rows[0][6].ToString();
                txtpin.Text = dt.Rows[0][7].ToString();
                txtcontact1.Text = dt.Rows[0][8].ToString();
                txtcontact2.Text = dt.Rows[0][9].ToString();
                txtcontact3.Text = dt.Rows[0][10].ToString();
                txtfax.Text = dt.Rows[0][11].ToString();
                txtemail.Text = dt.Rows[0][12].ToString();
                txtwebsite.Text = dt.Rows[0][13].ToString();


            }
            else
            {
                btnadd.Visible = true;
            }

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
           
            cmd = new SqlCommand("INSERT INTO Company (CompanyID, CompanyName, Address, Area, State, Country, City, PinCode, Contact1, Contact2, Contact3, FaxNo, EmailID, Website) VALUES    (@id,@name,@add,@area,@state,@country,@city,@pincode,@contact1,@contact2,@contact3,@faxno,@email,@website)", cn);
            cmd.Parameters.AddWithValue("@id", txtCompanyCode.Text);
            cmd.Parameters.AddWithValue("@name", txtCompanyName.Text);
            cmd.Parameters.AddWithValue("@add", txtaddress.Text);
            cmd.Parameters.AddWithValue("@area", txtarea.Text);
            cmd.Parameters.AddWithValue("@state", txtstate.Text);
            cmd.Parameters.AddWithValue("@country", txtcountry.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Parameters.AddWithValue("@pincode", txtpin.Text);
            cmd.Parameters.AddWithValue("@contact1", txtcontact1.Text);
            cmd.Parameters.AddWithValue("@contact2", txtcontact2.Text);
            cmd.Parameters.AddWithValue("@contact3", txtcontact3.Text);
            cmd.Parameters.AddWithValue("@faxno", txtfax.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            cmd.Parameters.AddWithValue("@website", txtwebsite.Text);

            cn.Open();
            cmd.ExecuteNonQuery();
            ClientScript.RegisterStartupScript(this.GetType(), "Message", "alert('data inserted ')", true);
            cn.Close();
            
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {

            btnadd.Visible = true;
            txtCompanyCode.Text = "";
            txtCompanyName.Text = "";
            txtaddress.Text = "";
            txtcity.Text = "";
            txtcountry.Text = "";
            txtarea.Text = "";
            txtstate.Text = "";
            txtpin.Text = "";
            txtcontact1.Text = "";
            txtcontact2.Text = "";
            txtcontact3.Text = "";
            txtfax.Text = "";
            txtemail.Text = "";
            txtwebsite.Text = "";
           
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            SqlConnection  cn = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlCommand cmd = new SqlCommand("UPDATE Company  SET  CompanyName = @CompanyName, Address = @Address, Area = @area, State = @state, Country = @country, City = @city, PinCode = @pincode, Contact1 = @contact1, Contact2 = @contact2,  Contact3 = @contact3, FaxNo = @faxno, EmailID = @emailid, Website = @website where   CompanyId=@cid",cn);
            cmd.Parameters.AddWithValue("@cid", Request.QueryString["cid"]);
            cmd.Parameters.AddWithValue("@companyname",txtCompanyName.Text);
            cmd.Parameters.AddWithValue("@address",txtaddress.Text);
            cmd.Parameters.AddWithValue("@area",txtarea.Text);
            cmd.Parameters.AddWithValue("@state",txtstate.Text);
            cmd.Parameters.AddWithValue("@country",txtcountry.Text);
            cmd.Parameters.AddWithValue("@city",txtcity.Text);
            cmd.Parameters.AddWithValue("@pincode",txtpin.Text);
            cmd.Parameters.AddWithValue("@contact1", txtcontact1.Text);
            cmd.Parameters.AddWithValue("@contact2", txtcontact2.Text);
            cmd.Parameters.AddWithValue("@contact3", txtcontact3.Text);
            cmd.Parameters.AddWithValue("@faxno", txtfax.Text);
            cmd.Parameters.AddWithValue("@emailid", txtemail.Text);
            cmd.Parameters.AddWithValue("@website", txtwebsite.Text);
 
            cn.Open();
            cmd.ExecuteNonQuery();

            cn.Close();
           
            
        }
    }
}
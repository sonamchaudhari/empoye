﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Employee_Development_System
{
    public partial class Calander : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CalDate.Visible = false;
            }

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (CalDate.Visible == false)
            {
                CalDate.Visible = true;
            }
            else
            {
                CalDate.Visible = false;
            }

        }

        protected void CalDate_SelectionChanged(object sender, EventArgs e)
        {
            txtdate.Text = CalDate.SelectedDate.ToString("d");
            CalDate.Visible = false;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace EDS.Self_Service
{
    public partial class E_leave : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                LeaveCodefill();
            }

        }


        public void LeaveCodefill()
        {
           adp = new SqlDataAdapter("Select LeaveCode From LeaveDefination", cn);
           dt = new DataTable();
             
           adp.Fill(dt);
           ddlleavecode.DataSource = dt;
           ddlleavecode.DataTextField = "LeaveCode";
           ddlleavecode.DataValueField = "LeaveCode";
           ddlleavecode.DataBind();
        }
        protected void btnadd_Click(object sender, EventArgs e)
        {
            cmd=new SqlCommand("INSERT INTO LeaveApplication (LeaveCode, EmpID, FromDate, ToDate, Half, ApplyDays, Reason, Remarks) VALUES  (@code,@id,@fdate,@tdate,@half,@days,@reason,@remarks)",cn);
             
            cmd.Parameters.AddWithValue("@code",ddlleavecode.SelectedValue);
            cmd.Parameters.AddWithValue("@id",Session["empid"].ToString());
            cmd.Parameters.AddWithValue("@fdate",txtfromdate.Text);
            cmd.Parameters.AddWithValue("@tdate",txttodate.Text);
            cmd.Parameters.AddWithValue("@half",ddlhalf.SelectedValue);
            cmd.Parameters.AddWithValue("@days",txtapplydays.Text);
             cmd.Parameters.AddWithValue("@reason",txtreason.Text);
             cmd.Parameters.AddWithValue("@remarks",txtremark.Text);
             cn.Open();
             cmd.ExecuteNonQuery();
             cn.Close();
             txtclear();

        
        }


        public void txtclear()
        {
            txtfromdate.Text = "";
            txttodate.Text = "";
            txtapplydays.Text = "";
            txtreason.Text = "";
            txtremark.Text = "";

        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtclear();
        }

        protected void ddlhalf_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EDS.Manage_Self_Service
{
    public partial class Eattendance : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
         
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        

        protected void btnshow_Click(object sender, EventArgs e)
        {
            cn.Open();
            DataTable dt = new DataTable();
            string Qry = "";
            Qry = " Select * from RowData Where  AttDate between '" + txtfromdate.Text + "' and '" + txttodate.Text + "' and  EmpID='" + Session["empid"].ToString().TrimEnd() + "'";
            adp = new SqlDataAdapter(Qry, cn);
            adp.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }




    }
}
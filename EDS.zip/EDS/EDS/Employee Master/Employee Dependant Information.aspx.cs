﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EDS.Employee_Information
{
    public partial class EmployeeDependentInformation : System.Web.UI.Page
    {
       
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                Empfill();
            }
        }
        

        protected void btnadd_Click(object sender, EventArgs e)
        {
             
            cmd = new SqlCommand("INSERT INTO EmployeeDependantDetail (EmpID, FName, MName, LName, Address, Country, State, City, Area, PinCode, Relationship, Contact1, Contact2, Contact3, EmailID, Gender, BloodGroup, DateOfBirth, MaritalStatus, Nationality, Occupation)VALUES (@empid,@fname,@mname,@lname,@address,@country,@state,@city,@area,@pincode,@relationship,@contact1,@contact2,@contact3,@emailid,@gender,@bloodgroup,@dateofbirth,@maritalstatus,@nationality,@occupation)", cn);
            cmd.Parameters.AddWithValue("@empid", ddlempname.SelectedValue);
             
            cmd.Parameters.AddWithValue("@fname", txtfname.Text);
            cmd.Parameters.AddWithValue("@mname",txtmname.Text);
            cmd.Parameters.AddWithValue("@lname",txtlname.Text);
            cmd.Parameters.AddWithValue("@address",txtaddress.Text);
            cmd.Parameters.AddWithValue("@country", txtcountry.Text);
            cmd.Parameters.AddWithValue("@state", txtstate.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Parameters.AddWithValue("@area", txtarea.Text);
            cmd.Parameters.AddWithValue("@pincode", txtpin.Text);
            cmd.Parameters.AddWithValue("@relationship",ddlrelationship.SelectedValue);
            cmd.Parameters.AddWithValue("@contact1", txtcontact.Text);
            cmd.Parameters.AddWithValue("@contact2", txtcontact2.Text);
            cmd.Parameters.AddWithValue("@contact3", txtcontact3.Text);
            cmd.Parameters.AddWithValue("@emailid", txtemail.Text);
            cmd.Parameters.AddWithValue("@gender", ddlgender.SelectedValue);
            cmd.Parameters.AddWithValue("@bloodgroup", ddlbloodgroup.SelectedValue);
            cmd.Parameters.AddWithValue("@dateofbirth", txtdob.Text);
            cmd.Parameters.AddWithValue("@maritalstatus", ddlmaritalstatus.SelectedValue);
            cmd.Parameters.AddWithValue("@nationality", txtnationality.Text);
            cmd.Parameters.AddWithValue("@occupation",txtoccupation.Text);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            txtclear();
        }




        public void Empfill()
        {
            adp = new SqlDataAdapter("Select EmpId,(FName+' '+MName+' '+LName)as Name From EmployeePersonalDetail Where EmpID='" + Session["empid"].ToString().TrimEnd() + "'", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddlempname.DataSource = dt;
            ddlempname.DataTextField = "Name";
            ddlempname.DataValueField = "EmpId";
            ddlempname.DataBind();
        }




        public void txtclear()
        {

            txtfname.Text = "";
            txtmname.Text = "";
            txtlname.Text = "";
            txtaddress.Text = "";
            txtcountry.Text = "";
            txtarea.Text = "";
            txtstate.Text = "";
            txtcity.Text = "";
            txtpin.Text = "";
            ddlrelationship.SelectedIndex = 0;
            txtcontact.Text = "";
            txtcontact2.Text = "";
            txtcontact3.Text = "";
            txtemail.Text = "";
            ddlgender.SelectedIndex = 0;
            ddlbloodgroup.SelectedIndex = 0;
            txtdob.Text = "";
            ddlmaritalstatus.SelectedIndex = 0;
            txtnationality.Text = "";
            txtoccupation.Text = "";
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtclear();
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
         
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBox1.Checked == true)
            {
                cmd = new SqlCommand("SELECT  Address, Country, State, City, Area, PinCode FROM  EmployeePersonalDetail where EmpID='" + ddlempname.SelectedValue + "'", cn);
                cn.Open();
                SqlDataReader rd ;
                rd = cmd.ExecuteReader();
                rd.Read();
                if (rd.HasRows)
                {
                    txtaddress.Text = rd["Address"].ToString();
                    txtcountry.Text = rd["Country"].ToString();
                    txtstate.Text = rd["State"].ToString();
                    txtcity.Text = rd["City"].ToString();
                    txtarea.Text = rd["Area"].ToString();
                    txtpin.Text = rd["PinCode"].ToString();
                }
                 
                cn.Close();
            
            }
        }

        //protected void btndelete_Click(object sender, EventArgs e)
        //{
        //    cmd = new SqlCommand("DELETE FROM EmployeeDependantDetail WHERE    (Relationship = @relation)  AND (EmpID = @id)", cn);
        //    cmd.Parameters.AddWithValue("@relation", ddlrelationship.SelectedItem.Text);
        //    cmd.Parameters.AddWithValue("@id", Session["empid"].ToString().Trim());
        //    cn.Open();
        //    cmd.ExecuteNonQuery();
        //    cn.Close();
        //    txtclear();
        //    GridView1.DataBind();
        //}
    }
}

       
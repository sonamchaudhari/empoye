﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EDS.Employee_Information
{
    public partial class Employee_Official_Information : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        SqlDataReader rd;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Companyfill();
                Branchfill();
                departmentfill();
                categoryfill();
                designationfill();
                shiftfill();
                bandfill();
                Empfill();
                empdatafill();
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }


        public void Companyfill()
        {
            adp = new SqlDataAdapter("SELECT   CompanyId, CompanyName  FROM    Company", cn);
            dt=new DataTable();
            dt.Clear();
            adp.Fill(dt);
           ddlcompany.DataSource = dt;
           ddlcompany.DataTextField = "CompanyName";
           ddlcompany.DataValueField = "CompanyId";
           ddlcompany.DataBind();
        }

        public void Branchfill()
        {
            adp = new SqlDataAdapter("Select BranchId,BranchName from Branch", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
           ddlbranch.DataSource = dt;
           ddlbranch.DataTextField = "BranchName";
           ddlbranch.DataValueField = "BranchId";
           ddlbranch.DataBind();
        }


        public void departmentfill()
        {
            adp = new SqlDataAdapter("SELECT DepartmentId, DepartmentName  FROM  Department", cn);

            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddldepartment.DataSource = dt;
            ddldepartment.DataTextField = "DepartmentName";
            ddldepartment.DataValueField = "DepartmentId";
            ddldepartment.DataBind();
        }

        public void categoryfill()
        {
            adp = new SqlDataAdapter("SELECT   CategoryCode, Category  FROM   Category", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddlcategory.DataSource = dt;
            ddlcategory.DataTextField = "Category";
            ddlcategory.DataValueField = "CategoryCode";
            ddlcategory.DataBind();
        }
        public void designationfill()
        {
            adp = new SqlDataAdapter("SELECT   DesignationCode, DesignationName   FROM   Designation", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddldesignation.DataSource = dt;
            ddldesignation.DataTextField = "DesignationName";
            ddldesignation.DataValueField = "DesignationCode";
            ddldesignation.DataBind();
        }
        public void shiftfill()
        {
            adp = new SqlDataAdapter("SELECT  ShiftCode,ShiftName  FROM   ShiftMaster", cn);
            dt = new DataTable();
            adp.Fill(dt);
            ddlShift.DataSource = dt;
            ddlShift.DataTextField = "ShiftName";
            ddlShift.DataValueField = "ShiftCode";
            ddlShift.DataBind();
        }

        public void bandfill()
        {
            adp = new SqlDataAdapter("SELECT  * FROM Band", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddlBandName.DataSource = dt;
            ddlBandName.DataTextField = "BandName";
            ddlBandName.DataValueField = "BandCode";
            ddlBandName.DataBind();
        }


        public void Empfill()
        {
            adp = new SqlDataAdapter("Select EmpID,(FName+' '+MName+' '+LName)as Name From EmployeePersonalDetail", cn);
            dt = new DataTable();

            dt.Clear();
            adp.Fill(dt);
            ddlReporting.DataSource = dt;
            ddlReporting.DataTextField = "Name";
            ddlReporting.DataValueField = "EmpID";
            ddlReporting.DataBind();
        }


        

        
        protected void btnadd_Click(object sender, EventArgs e)
        {                                                                                   //   Shift
            string qry;                                                        // , BankAcccountNo, BankName   ,,'"+txtBankName.Text+"'  ,'" + ddlshift.SelectedValue + "','" + txtBankacNo.Text + "',BankAcccountNo  ,'"+txtBankName.Text+"' , BankName BankCardNo  IFCcode  ReportingTo
            qry = @"INSERT INTO EmployeeOfficialDetail (Company,EmpID, Branch, Department, Category, Designation, DateOfJoin,DateOfConfirm, DateOfRetriment,  PFno, ESIno, PANno,WeeklyOff , BasicSalary, Active, Shift, BankAcccountNo, BankName, BankCardNo, IFCcode, ReportingTo, BandName)
                       values ('" + ddlcompany.SelectedItem.Text + "','" + Session["empid"].ToString() + "','" + ddlbranch.SelectedItem.Text + "' ,'" + ddldepartment.SelectedItem.Text + "','" + ddlcategory.SelectedItem.Text + "','" + ddldesignation.SelectedItem.Text + "','" + txtdateofjoin.Text + "','" + txtdateofconfirm.Text + "','" + txtdofretriment.Text + "','" + txtpfno.Text + "','" + txtesino.Text + "','" + txtpanno.Text + "','" + Weeklyoff.SelectedValue + "','" + txtbasicSalary.Text + "','" + ddlactive.SelectedValue + "','" + ddlShift.SelectedItem.Text + "','" + txtbankaccountno.Text + "','" + txtbankName.Text + "','" + txtbankcard.Text + "','" + txtIFCno.Text + "','" + ddlReporting.SelectedItem.Text + "','" + ddlBandName.SelectedItem.Text + "')";
            cmd = new SqlCommand(qry, cn);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            txtclear();
            
            

        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            btnadd.Visible = true;
            txtclear();
        }

        public void txtclear()
        {
            txtdateofjoin.Text = "";
            txtdateofconfirm.Text = "";
            txtpfno.Text = "";
            txtdofretriment.Text = "";
            txtesino.Text = "";
            txtpanno.Text = "";
            Weeklyoff.SelectedIndex = 0;
            txtbasicSalary.Text = "";
            ddlactive.SelectedIndex = 0;
            txtbankaccountno.Text = "";
            txtbankName.Text = "";
            txtbankcard.Text = "";
            txtIFCno.Text = "";
        }


        public void empdatafill()
        {
            cn.Open();
            cmd = new SqlCommand("SELECT * FROM   EmployeeOfficialDetail where EmpID='" + Session["empid"].ToString() + "'", cn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {

                ddlcompany.SelectedItem.Text = rd["Company"].ToString();
                ddlbranch.SelectedItem.Text = rd["Branch"].ToString();
                ddldepartment.SelectedItem.Text = rd["Department"].ToString();
                ddlcategory.SelectedItem.Text = rd["Category"].ToString();
                ddldesignation.SelectedItem.Text = rd["Designation"].ToString();
                txtdateofjoin.Text = rd["DateOfJoin"].ToString();
                txtdateofconfirm.Text = rd["DateOfConfirm"].ToString();
                txtdofretriment.Text = rd["DateOfRetriment"].ToString();
                txtpfno.Text = rd["PFno"].ToString();

                txtesino.Text = rd["ESIno"].ToString();
                txtpanno.Text = rd["PANno"].ToString();
                Weeklyoff.SelectedItem.Text = rd["WeeklyOff"].ToString();
                txtbasicSalary.Text = rd["BasicSalary"].ToString();
                ddlactive.SelectedItem.Text = rd["Active"].ToString();
                ddlShift.SelectedItem.Text = rd["Shift"].ToString();
                txtbankaccountno.Text = rd["BankAcccountNo"].ToString();
                txtbankName.Text = rd["BankName"].ToString();
                txtbankcard.Text = rd["BankCardNo"].ToString();
                txtIFCno.Text = rd["IFCcode"].ToString();
                ddlReporting.SelectedItem.Text = rd["ReportingTo"].ToString();
                ddlBandName.SelectedItem.Text = rd["BandName"].ToString();
                btnadd.Visible = false;

            }
        }
    }
}
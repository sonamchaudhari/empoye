﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EDS.Employee_Information
{
    public partial class EmployeePersonaInformation : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataReader rd ;
        protected void Page_Load(object sender, EventArgs e)
        {

            
            if (!IsPostBack)
            {
                txtempcode.Text = Session["empid"].ToString().Trim();
                empdatafill();
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }

        }


        public void empdatafill()
        {
            cn.Open();
            cmd = new SqlCommand("SELECT * FROM   EmployeePersonalDetail where EmpID='" + Session["empid"].ToString() + "'", cn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                txtfname.Text = rd["FName"].ToString();
                txtmname.Text = rd["MName"].ToString();
                txtlname.Text = rd["LName"].ToString();
                txtadd.Text = rd["Address"].ToString();

                txtcountry.Text = rd["Country"].ToString();
                txtstate.Text = rd["State"].ToString();

                txtcity.Text = rd["City"].ToString();
                txtarea.Text = rd["Area"].ToString();
                txtpin.Text = rd["PinCode"].ToString();
                txtmaddress.Text = rd["MaillingAddress"].ToString();
                txtmcountry.Text = rd["MaillingCountry"].ToString();
                txtmstate.Text = rd["MaillingState"].ToString();
                txtmcity.Text = rd["MaillingCity"].ToString();
                txtmarea.Text = rd["MaillingArea"].ToString();
                txtmpin.Text = rd["MaillingPinNo"].ToString();

                txtcontact.Text = rd["Contact1"].ToString();
                txtcontact2.Text = rd["Contact2"].ToString();
                txtcontact3.Text = rd["Contact3"].ToString();
                txtemail.Text = rd["Email"].ToString();
                ddlgender.SelectedItem.Text = rd["Gender"].ToString();
                ddlbloodgroup.SelectedItem.Text = rd["BloodGroup"].ToString();
                txtdob.Text = rd["DateOfBirth"].ToString();
                ddlmaritalstatus.SelectedItem.Text = rd["MaritalStatus"].ToString();
                txtnationality.Text = rd["Nationality"].ToString();
                txtqualification.Text = rd["Qulification"].ToString();
                txtlicense.Text = rd["LicenseNo"].ToString();
                btnadd.Visible = false;


            }
             
             
            

       }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO EmployeePersonalDetail (EmpID, FName, MName, LName, Address, Country, State, City, Area, PinCode, MaillingAddress, MaillingCountry, MaillingState, MaillingCity, MaillingArea, MaillingPinNo, Contact1, Contact2, Contact3, Email,Gender, BloodGroup, DateOfBirth, MaritalStatus, Nationality, Qulification, LicenseNo) VALUES        (@empid,@firstname,@middlename,@lastname,@address,@country,@state,@city,@area,@pincode,@maddress,@mcountry,@mstate,@mcity,@marea,@mpincode,@contact1,@contact2,@contact3,@emailid,@gender,@bloodgroup,@dateofbirth,@maritalstatus,@nationality,@qualification,@licenseno)", cn);
            cmd.Parameters.AddWithValue("@empid", txtempcode.Text);
            cmd.Parameters.AddWithValue("@firstname", txtfname.Text);
            cmd.Parameters.AddWithValue("@middlename", txtmname.Text);
            cmd.Parameters.AddWithValue("@lastname", txtlname.Text);
            cmd.Parameters.AddWithValue("@address", txtadd.Text);
            cmd.Parameters.AddWithValue("@country", txtcountry.Text);
            
            cmd.Parameters.AddWithValue("@state", txtstate.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Parameters.AddWithValue("@area", txtarea.Text);
            cmd.Parameters.AddWithValue("@pincode", txtpin.Text);
            cmd.Parameters.AddWithValue("@maddress", txtmaddress.Text);
            cmd.Parameters.AddWithValue("@mcountry", txtcountry.Text);
            cmd.Parameters.AddWithValue("@mstate", txtstate.Text);
            cmd.Parameters.AddWithValue("@mcity", txtcity.Text);
            cmd.Parameters.AddWithValue("@marea", txtmarea.Text);
            cmd.Parameters.AddWithValue("@mpincode", txtmpin.Text);
            cmd.Parameters.AddWithValue("@contact1", txtcontact.Text);
            cmd.Parameters.AddWithValue("@contact2", txtcontact2.Text);
            cmd.Parameters.AddWithValue("@contact3", txtcontact3.Text);
            cmd.Parameters.AddWithValue("@emailid", txtemail.Text);
            cmd.Parameters.AddWithValue("@gender", ddlgender.SelectedValue);
            cmd.Parameters.AddWithValue("@bloodgroup", ddlbloodgroup.SelectedValue);
            cmd.Parameters.AddWithValue("@dateofbirth", txtdob.Text);
            cmd.Parameters.AddWithValue("@maritalstatus", ddlmaritalstatus.SelectedValue);
            cmd.Parameters.AddWithValue("@nationality", txtnationality.Text);
            cmd.Parameters.AddWithValue("@qualification", txtqualification.Text);
            cmd.Parameters.AddWithValue("@licenseno", txtlicense.Text);


            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();


            cmd = new SqlCommand("INSERT INTO EmploeePersonalDetailView (EmpID, FName, MName, LName, Address, Country, State, City, Area, PinCode, MaillingAddress, MaillingCountry, MaillingState, MaillingCity, MaillingArea, MaillingPinNo, Contact1, Contact2, Contact3, Email,Gender, BloodGroup, DateOfBirth, MaritalStatus, Nationality, Qulification, LicenseNo) VALUES        (@empid,@firstname,@middlename,@lastname,@address,@country,@state,@city,@area,@pincode,@maddress,@mcountry,@mstate,@mcity,@marea,@mpincode,@contact1,@contact2,@contact3,@emailid,@gender,@bloodgroup,@dateofbirth,@maritalstatus,@nationality,@qualification,@licenseno)", cn);
            cmd.Parameters.AddWithValue("@empid", txtempcode.Text);
            cmd.Parameters.AddWithValue("@firstname", txtfname.Text);
            cmd.Parameters.AddWithValue("@middlename", txtmname.Text);
            cmd.Parameters.AddWithValue("@lastname", txtlname.Text);
            cmd.Parameters.AddWithValue("@address", txtadd.Text);
            cmd.Parameters.AddWithValue("@country", txtcountry.Text);
            
            cmd.Parameters.AddWithValue("@state", txtstate.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Parameters.AddWithValue("@area", txtarea.Text);
            cmd.Parameters.AddWithValue("@pincode", txtpin.Text);
            cmd.Parameters.AddWithValue("@maddress", txtmaddress.Text);
            cmd.Parameters.AddWithValue("@mcountry", txtcountry.Text);
            cmd.Parameters.AddWithValue("@mstate", txtstate.Text);
            cmd.Parameters.AddWithValue("@mcity", txtcity.Text);
            cmd.Parameters.AddWithValue("@marea", txtmarea.Text);
            cmd.Parameters.AddWithValue("@mpincode", txtmpin.Text);
            cmd.Parameters.AddWithValue("@contact1", txtcontact.Text);
            cmd.Parameters.AddWithValue("@contact2", txtcontact2.Text);
            cmd.Parameters.AddWithValue("@contact3", txtcontact3.Text);
            cmd.Parameters.AddWithValue("@emailid", txtemail.Text);
            cmd.Parameters.AddWithValue("@gender", ddlgender.SelectedValue);
            cmd.Parameters.AddWithValue("@bloodgroup", ddlbloodgroup.SelectedValue);
            cmd.Parameters.AddWithValue("@dateofbirth", txtdob.Text);
            cmd.Parameters.AddWithValue("@maritalstatus", ddlmaritalstatus.SelectedValue);
            cmd.Parameters.AddWithValue("@nationality", txtnationality.Text);
            cmd.Parameters.AddWithValue("@qualification", txtqualification.Text);
            cmd.Parameters.AddWithValue("@licenseno", txtlicense.Text);


            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();

            
            txtclear();
            lblmessage.Visible = true;
            lblmessage.Text = "Record Inserted";
        }

        public void txtclear()
        {
            txtempcode.Text = "";
            txtfname.Text = "";
            txtmname.Text = "";
            txtlname.Text = "";
            txtadd.Text = "";
            txtarea.Text = "";
            txtcountry.Text = "";
            txtstate.Text = "";
            txtpin.Text = "";
            txtcity.Text = "";
            txtmaddress.Text = "";
            txtmcountry.Text = "";
            txtmstate.Text = "";
            txtmarea.Text = "";
            txtmpin.Text = "";
            txtmcity.Text = "";
            txtcontact.Text = "";
            txtcontact2.Text = "";
            txtcontact3.Text = "";
            txtemail.Text = "";
            ddlgender.SelectedIndex = 0;
            ddlbloodgroup.SelectedIndex = 0;
            txtdob.Text = "";
            ddlmaritalstatus.SelectedIndex = 0;
            txtnationality.Text = "";
            txtqualification.Text = "";
            txtlicense.Text = "";


        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
             
            txtclear();

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {


            if (CheckBox1.Checked == true)
            {
                txtmaddress.Text = txtadd.Text;
                txtmcountry.Text = txtcountry.Text;
                txtmstate.Text = txtstate.Text;
                txtmarea.Text = txtarea.Text;
                txtmpin.Text = txtpin.Text;
                txtmcity.Text = txtcity.Text;

            }
             
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand(" DELETE FROM EmployeePersonalDetail where EmpID=@id", cn);
            cmd.Parameters.AddWithValue("@id", txtempcode.Text);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            btnadd.Visible = true;
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand(@"UPDATE  EmployeePersonalDetail  SET   FName =@firstname, MName =@middlename, LName =@lastname, Address =@address, Country =@country, State =@state, City =@city, Area =@area, PinCode =@pincode, MaillingAddress =@maddress, MaillingCountry =@mcountry, MaillingState =@mstate, MaillingCity =@mcity, MaillingArea =@marea, MaillingPinNo =@mpincode, Contact1 =@contact1,   Contact2 =@contact2, Contact3 =@contact3, Email =@emailid, Gender =@gender, BloodGroup =@bloodgroup, DateOfBirth =@dateofbirth, MaritalStatus =@maritalstatus, Nationality =@nationality, Qulification =@qualification, LicenseNo =@licenseno     WHERE (EmpID = @id)", cn);


            cmd.Parameters.AddWithValue("@id", Session["empid"].ToString());
            cmd.Parameters.AddWithValue("@firstname", txtfname.Text);
            cmd.Parameters.AddWithValue("@middlename", txtmname.Text);
            cmd.Parameters.AddWithValue("@lastname", txtlname.Text);
            cmd.Parameters.AddWithValue("@address", txtadd.Text);
            cmd.Parameters.AddWithValue("@country", txtcountry.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Parameters.AddWithValue("@state", txtstate.Text);
            cmd.Parameters.AddWithValue("@area", txtarea.Text);
            cmd.Parameters.AddWithValue("@pincode", txtpin.Text);
            cmd.Parameters.AddWithValue("@maddress", txtmaddress.Text);
            cmd.Parameters.AddWithValue("@mcountry", txtcountry.Text);
            cmd.Parameters.AddWithValue("@mstate", txtstate.Text);
            cmd.Parameters.AddWithValue("@mcity", txtcity.Text);
            cmd.Parameters.AddWithValue("@marea", txtmarea.Text);
            cmd.Parameters.AddWithValue("@mpincode", txtmpin.Text);
            cmd.Parameters.AddWithValue("@contact1", txtcontact.Text);
            cmd.Parameters.AddWithValue("@contact2", txtcontact2.Text);
            cmd.Parameters.AddWithValue("@contact3", txtcontact3.Text);
            cmd.Parameters.AddWithValue("@emailid", txtemail.Text);
            cmd.Parameters.AddWithValue("@gender", ddlgender.SelectedValue);
            cmd.Parameters.AddWithValue("@bloodgroup", ddlbloodgroup.SelectedValue);
            cmd.Parameters.AddWithValue("@dateofbirth", txtdob.Text);
            cmd.Parameters.AddWithValue("@maritalstatus", ddlmaritalstatus.SelectedValue);
            cmd.Parameters.AddWithValue("@nationality", txtnationality.Text);
            cmd.Parameters.AddWithValue("@qualification", txtqualification.Text);
            cmd.Parameters.AddWithValue("@licenseno", txtlicense.Text);


            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        protected void ddlgender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        


    }
}
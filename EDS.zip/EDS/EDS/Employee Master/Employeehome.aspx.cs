﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace EDS.Employee_Master
{
    public partial class Employeehome : System.Web.UI.Page
    {
         SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand com;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)//Page_Load
            {
                ComEvent();
                OtherEvent();

            }
        }   
            public void ComEvent()
              {
            SqlDataAdapter da1;
            DataTable dt=new DataTable();
            conn.Open();
            da1 = new SqlDataAdapter("select * From CompanyEvent", conn);
            dt.Clear();
            da1.Fill(dt);
            if (dt.Rows.Count > 0)
            {

               CompanyEvent.Text = dt.Rows[0]["CompanyEvent"].ToString();
            }
            conn.Close();
             }

        public void OtherEvent()
        {
            SqlDataAdapter da2;
            DataTable dt = new DataTable();
            conn.Open();
            da2 = new SqlDataAdapter("select * From OtherEvent", conn);
            dt.Clear();
            da2.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                OthEvent.Text = dt.Rows[0]["OtherEvent"].ToString();
            }
            conn.Close();
        }
         
    }
}
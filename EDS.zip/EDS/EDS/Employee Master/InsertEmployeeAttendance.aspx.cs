﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EDS.Employee_Master
{
    public partial class InsertEmployeeAttendance : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO RowData  (EmpID,AttDate, InTime, OutTime)VALUES  (@empid,@date,@intime,@outtime)", cn);
            cmd.Parameters.AddWithValue("@empid", Session["empid"].ToString().Trim());
            cmd.Parameters.AddWithValue("@date", txtdate.Text);
            cmd.Parameters.AddWithValue("@intime", txtintime.Text);
            cmd.Parameters.AddWithValue("@outtime", txtouttime.Text);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            txtclear();
        }
        public void txtclear()
        {
            txtintime.Text = "";
            txtouttime.Text = "";

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EDS
{
    public partial class Home : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["empid"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            if (!IsPostBack)
            {
                ComEventfill();
                OtherEventfill();
                
            }
        }


        public void ComEventfill()
        {
            SqlDataAdapter da1;
            DataTable dt=new DataTable();
            cn.Open();
            da1 = new SqlDataAdapter("select * From CompanyEvent", cn);
            dt.Clear();
            da1.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                companyevent.Text = dt.Rows[0]["CompanyEvent"].ToString();
            }
            cn.Close();
        }



        public void OtherEventfill()
        {
            SqlDataAdapter da2;
            DataTable dt = new DataTable();
            cn.Open();
            da2 = new SqlDataAdapter("select * From OtherEvent", cn);
            dt.Clear();
            da2.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                otherevent.Text = dt.Rows[0]["OtherEvent"].ToString();
            }
            cn.Close();
        }

        


        //public void EmpEventfill()
        //{
        //    cn.Open();
        //    DataTable dt = new DataTable();
        //    SqlDataAdapter da;
        //    var CDate = DateTime.Now.ToString("dd-MM");
             
        //    int i;
        //    da = new SqlDataAdapter("select (FName+' '+MName+' '+LName)as Name From EmployeePersonalDetail where Bdate='" + CDate + "'", cn);
        //    da.Fill(dt);
        //    if (dt.Rows.Count > 0)
        //    {


        //        string[] arrvalue = new string[dt.Rows.Count];
        //        for (i = 0; i < dt.Rows.Count; i++)
        //        {
        //            arrvalue[i] = dt.Rows[i]["EName"].ToString();
        //            TextBox1.Text += "* Happy Birthday To " + arrvalue[i] + "\n\n";
        //        }
        //    }
        //    cn.Close();

        //}
    }


}
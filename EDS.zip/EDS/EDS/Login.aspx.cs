﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Employee_Development_System
{
    public partial class Login : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
             
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            cn.Open();

            cmd = new SqlCommand("INSERT INTO UserLogin (UserLogin, Password) VALUES (@userid,@pwd)", cn);
            cmd.Parameters.AddWithValue("@userid", txtid.Text);
            cmd.Parameters.AddWithValue("@pwd", txtpass.Text);

            cmd.ExecuteNonQuery();
            //if (txtid.Text == "Admin" && txtpass.Text == "Admin123")
            //{
            //    Session["empid"] = "Admin";
            //    Session["pass"] = "Admin123";

            //    Response.Redirect("Home.aspx");

            //}
            //else
            //{
                dt = new DataTable();
                adp = new SqlDataAdapter("Select EmpID,Password from RagisterUser where EmpID ='" + txtid.Text + "' and Password='" + txtpass.Text + "'", cn);
                adp.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    Session["empid"] = dt.Rows[0]["EmpID"].ToString();
                    Session["pass"] = dt.Rows[0]["Password"].ToString();
                    SqlDataReader rd;
                    
                    cmd = new SqlCommand("Select UserType From RagisterUser Where EmpID='" + Session["empid"] + "'", cn);
                    rd = cmd.ExecuteReader();
                    rd.Read();
                    Session["UserType"] = rd["UserType"];
                    if (Session["UserType"].ToString() == "Manager")
                    {

                        Response.Redirect("Home.aspx");
                    }
                    else
                    {
                        Response.Redirect("Home.aspx");
                    }
                    





               // }

            }

            
             
            cn.Close();
            cmd.Dispose();
            txtclear();


        }


        

        public void txtclear()
        {
             txtid.Text = "";
            txtpass.Text = "";
        }
    }
}
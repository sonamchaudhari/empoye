﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace EDS.Setting
{
    public partial class Company_Event : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                txtfill();
            }

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            if (txtcompanyevent.Text != "")
            {
                cn.Open();
                cmd = new SqlCommand("Delete From CompanyEvent", cn);
                cmd.ExecuteNonQuery();
                cn.Close();
                cn.Open();
                cmd = new SqlCommand("Insert into CompanyEvent Values('" + txtcompanyevent.Text + "')", cn);
                cmd.ExecuteNonQuery();
                cn.Close();
            }
        
        }

        public void txtfill()
        {
            SqlDataAdapter adp;
            DataTable dt = new DataTable();
            cmd = new SqlCommand("select CompanyEvent from CompanyEvent ", cn);
            adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            txtcompanyevent.Text = dt.Rows[0][0].ToString();



        }
 

        protected void btncancel_Click(object sender, EventArgs e)
        {
            txtcompanyevent.Text = "";
        }
    }
}
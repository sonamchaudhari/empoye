﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace EDS.Self_Service
{
    public partial class E_Attendance : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        
        SqlDataAdapter adp;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                Empfill();
            }
        }
        public void Empfill()
        {
            adp = new SqlDataAdapter("Select EmpId,(FName+' '+MName+' '+LName)as Name From EmployeePersonalDetail ", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            employeename.DataSource = dt;
            employeename.DataTextField = "Name";
            employeename.DataValueField = "EmpID";
            employeename.DataBind();
            employeename.Items.Insert(0, new ListItem("All"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            cn.Open();
            DataTable dt = new DataTable();
           string qry = "";
            string emp = employeename.SelectedValue ;
            if (emp == "All")
            {
                qry = "SELECT *  FROM  RowData Where  AttDate between '" + txtfromdate.Text + "' and '" + txttodate.Text + "' ";
            }

            else
            {

                qry = "SELECT *  FROM  RowData Where  AttDate between '" + txtfromdate.Text + "' and '" + txttodate.Text + "' and EmpID='" + emp + "'";
            }
            adp = new SqlDataAdapter(qry,cn);
            adp.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

           
        }

        protected void employeename_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace EDS.Manage_Self_Service
{
    public partial class Eleave_Process : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        //SqlCommand cmd;
        SqlDataAdapter adp;
        //DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            gridfill();
        }

        public void gridfill()
        {
           // string Month = DLMonth.SelectedValue;
            string Qry;
            DataTable dt = new DataTable();
            Qry = " Select * From LeaveApplication Where  Fromdate  between'" + txtfromdate.Text + "' and '" + txttodate.Text + "'";

            adp = new SqlDataAdapter(Qry, cn);
            dt.Clear();
            adp.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}
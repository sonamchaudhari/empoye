﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace EDS.Manager_Master
{
    public partial class ManagerMaster : System.Web.UI.MasterPage
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        SqlDataReader rd;
        protected void Page_Load(object sender, EventArgs e)
        {
            var menu = Page.Master.FindControl("NavigationMenu") as Menu;

            if (!IsPostBack)
            {

                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }




                if (Session["empid"].ToString().Trim() == "Employee")
                {
                    
                }



                getemp();
                //getphoto();
            }


        }
        public void getemp()
        {
            cn.Open();

            cmd = new SqlCommand("Select EmpID,(FName+' '+MName+' '+LName)as Name From EmployeePersonalDetail Where EmpID='" + Session["empid"] + " '", cn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                if (rd["Name"].ToString() != " ")
                {
                    lblname.Text = rd["Name"].ToString();
                }
            }
            cn.Close();

        }
       
    }
}
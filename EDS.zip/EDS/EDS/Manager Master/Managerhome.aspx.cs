﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace EDS.Manager_Master
{
    public partial class Managerhome : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ComEventfill();
                OtherEventfill();
                
            }
        }


         public void ComEventfill()
        {
            SqlDataAdapter da1;
            DataTable dt=new DataTable();
            cn.Open();
            da1 = new SqlDataAdapter("select * From CompanyEvent", cn);
            dt.Clear();
            da1.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                companyevent.Text = dt.Rows[0]["CompanyEvent"].ToString();
            }
            cn.Close();
        }

        public void OtherEventfill()
        {
            SqlDataAdapter da2;
            DataTable dt = new DataTable();
            cn.Open();
            da2 = new SqlDataAdapter("select * From OtherEvent", cn);
            dt.Clear();
            da2.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                otherevent.Text = dt.Rows[0]["OtherEvent"].ToString();
            }
            cn.Close();
        }

        
    }
}

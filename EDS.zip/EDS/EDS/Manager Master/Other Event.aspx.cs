﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EDS.Setting
{
    public partial class Other_Event : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                txtfill();
            }

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            if (txtotherevent.Text != "")
            {
                cn.Open();
                cmd = new SqlCommand("Delete From OtherEvent", cn);
                cmd.ExecuteNonQuery();
                cn.Close();
                cn.Open();
                cmd = new SqlCommand("Insert into OtherEvent Values('" + txtotherevent.Text + "')", cn);
                cmd.ExecuteNonQuery();
                cn.Close();
            }
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            txtotherevent.Text = "";
        }


        public void txtfill()
        {
            SqlDataAdapter adp;
            DataTable dt = new DataTable();
            cmd = new SqlCommand("select OtherEvent from OtherEvent ", cn);
            adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            txtotherevent.Text = dt.Rows[0][0].ToString();



        }
    }
}
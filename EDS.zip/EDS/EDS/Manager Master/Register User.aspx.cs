﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


 using System.IO;


namespace EDS.Setting
{
    public partial class Register_User : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        string filename = "";
        //SqlDataAdapter adp;
        //DataTable dt;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtclear();
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO RagisterUser  (EmpID, Password, UserType, FileUpload) VALUES (@empid,@password,@usertype,@fileupload)", cn);
            cmd.Parameters.AddWithValue("@empid", txtempcode.Text);
            cmd.Parameters.AddWithValue("@password", txtpassword.Text);
            cmd.Parameters.AddWithValue("@usertype",ddlusertype.SelectedValue);
            cmd.Parameters.AddWithValue("@fileupload", Label4.Text);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            GridView1.DataBind();
            txtclear();

        }

        protected void btnupload_Click(object sender, EventArgs e)
        {
            if (empfileupload.HasFile)
            {
                string ext = Path.GetExtension(empfileupload.FileName);
                filename = txtempcode.Text + ext;
                empfileupload.SaveAs(Server.MapPath("~/EmpPhoto/") + filename);
                empphoto.ImageUrl = "~/EmpPhoto/"+filename;
                Label4.Text = filename;
            
            
           //  string ext = Path.GetExtension(FUEmpReq.FileName );
           // funame = txtEmpCode.Text + ext;
           // FUEmpReq.SaveAs(Server.MapPath("~/EmployeePhoto/") + funame);
            
           // EmpPhoto.ImageUrl = "~/EmployeePhoto/"+funame  ;
           // Label4.Text = funame
            
            }
             
        }

        public void txtclear()
        {
            txtempcode.Text = "";
            txtpassword.Text = "";
            ddlusertype.SelectedIndex = 0;
        }
         
         
         
    }
}
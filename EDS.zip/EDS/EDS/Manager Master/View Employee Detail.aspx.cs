﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EDS.Manage_Self_Service
{
    public partial class View_Employee_Detail : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        string Qry;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                Companyfill();
                Branchfill();
                departmentfill();
                categoryfill();
                designationfill();
                 

            }
        }

        public void Companyfill()
        {
            adp = new SqlDataAdapter("SELECT   CompanyId, CompanyName  FROM    Company", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddlcompany.DataSource = dt;
            ddlcompany.DataTextField = "CompanyName";
            ddlcompany.DataValueField = "CompanyId";
            ddlcompany.DataBind();
            ddlcompany.Items.Insert(0, new ListItem("All"));
        }

        public void Branchfill()
        {
            adp = new SqlDataAdapter("Select BranchId,BranchName from Branch", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddlbranch.DataSource = dt;
            ddlbranch.DataTextField = "BranchName";
            ddlbranch.DataValueField = "BranchId";
            ddlbranch.DataBind();
            ddlbranch.Items.Insert(0, new ListItem("All"));
        }


        public void departmentfill()
        {
            adp = new SqlDataAdapter("SELECT DepartmentId, DepartmentName  FROM  Department", cn);

            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddldepartment.DataSource = dt;
            ddldepartment.DataTextField = "DepartmentName";
            ddldepartment.DataValueField = "DepartmentId";
            ddldepartment.DataBind();
            ddldepartment.Items.Insert(0, new ListItem("All"));
        }

        public void categoryfill()
        {
            adp = new SqlDataAdapter("SELECT   CategoryCode, Category  FROM   Category", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddlcategory.DataSource = dt;
            ddlcategory.DataTextField = "Category";
            ddlcategory.DataValueField = "CategoryCode";
            ddlcategory.DataBind();
            ddlcategory.Items.Insert(0, new ListItem("All"));
        }
        public void designationfill()
        {
            adp = new SqlDataAdapter("SELECT   DesignationCode, DesignationName   FROM   Designation", cn);
            dt = new DataTable();
            dt.Clear();
            adp.Fill(dt);
            ddldesignation.DataSource = dt;
            ddldesignation.DataTextField = "DesignationName";
            ddldesignation.DataValueField = "DesignationCode";
            ddldesignation.DataBind();
            ddldesignation.Items.Insert(0, new ListItem("All"));
        }

        protected void btnEmpPersonal_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
            
            //Qry = "Select * from EmployeePersonalDetail";
            // if (ddlcompany.Text != "All")
            //{
            //    Qry += " Where CompanyName='" + ddlcompany.SelectedItem.Text + "'";
            //}
            //if (ddlbranch.Text != "All")
            //{
            //    Qry += " and BranchName='" + ddlbranch.SelectedItem.Text + "'";
            //}
            //if (ddldepartment.Text != "All")
            //{
            //    Qry += " and DepartmentName='" + ddldepartment.SelectedItem.Text + "'";
            //}
            //if (ddldesignation.Text != "All")
            //{
            //    Qry += " and DesignationName='" + ddldesignation.SelectedItem.Text + "'";
            //}
            //if (ddlcategory.Text != "All")
            //{
            //    Qry += " and CategoryName='" + ddlcategory.SelectedItem.Text + "'";
            //}
            //adp = new SqlDataAdapter(Qry, cn);
            //dt = new DataTable();
            //dt.Clear();
            //adp.Fill(dt);
            //GridEmpPersonal.DataSource = dt;
            //GridEmpPersonal.DataBind();

        }

        protected void btnEmpOfficial_Click(object sender, EventArgs e)
        {
           
           MultiView1.ActiveViewIndex = 2;
            Qry = "Select * from EmployeeOfficialDetail";
            if (ddlcompany.Text != "All")
            {
                Qry += " Where Company='" + ddlcompany.SelectedItem.Text + "'";
            }
            if (ddlbranch.Text != "All")
            {
                Qry += " and Branch='" + ddlbranch.SelectedItem.Text + "'";
            }
            if (ddldepartment.Text != "All")
            {
                Qry += " and Department='" + ddldepartment.SelectedItem.Text + "'";
            }
            if (ddldesignation.Text != "All")
            {
                Qry += " and Designation='" + ddldesignation.SelectedItem.Text + "'";
            }
            if (ddlcategory.Text != "All")
            {
                Qry += " and Category='" + ddlcategory.SelectedItem.Text + "'";
            }
            adp = new SqlDataAdapter(Qry, cn);
            dt = new DataTable();
            adp.Fill(dt);
            GridEmpOfficial.DataSource = dt;
            GridEmpOfficial.DataBind();

        }

        protected void btnEmpDependent_Click(object sender, EventArgs e)
        {

        }

        
    }
}
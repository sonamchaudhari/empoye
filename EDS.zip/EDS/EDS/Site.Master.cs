﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

 


namespace EDS
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter adp;
        SqlDataReader rd;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            var menu = Page.Master.FindControl("NavigationMenu") as Menu;
            
            if (!IsPostBack)
            {

                if (Session["empid"] == null)
                {
                    Response.Redirect("Login.aspx");
                }




               

                getemp();
                getphoto();
            }

            if (Session["UserType"].ToString().Trim() == "Employee")
            {
                NavigationMenu.Items.Remove(NavigationMenu.FindItem("Master"));
                NavigationMenu.Items.Remove(NavigationMenu.FindItem("Setting"));
                NavigationMenu.Items.Remove(NavigationMenu.FindItem("Manager Self Service"));

            }
            if (Session["UserType"].ToString().Trim() == "Manager")
            {
                NavigationMenu.Items.Remove(NavigationMenu.FindItem("Master"));
            }

                
             
        }


        public void getemp()
        {
            cn.Open();
            
            cmd = new SqlCommand("Select EmpID,(FName+' '+MName+' '+LName)as Name From EmployeePersonalDetail Where EmpID='"+ Session["empid"] +" '", cn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                if (rd["Name"].ToString() != " ")
                {
                    lblname.Text = rd["Name"].ToString();
                }
            }
            cn.Close();

        }


        public void getphoto()
        {
            string emp = Session["empid"].ToString();
            ImgEmpPhoto.ImageUrl = "~/EmployeePhoto/" + emp.TrimEnd() + ".jpg";
        }

      
    }
}
 

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace EDS
{




    public partial class UserLogin : System.Web.UI.Page
    {

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        SqlDataAdapter da = new SqlDataAdapter();
        DataTable dt = new DataTable();
        SqlCommand cmd = new SqlCommand();
       // SqlDataReader rd;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (txtuserlogin.Text == "Admin" && txtpassword.Text == "Admin123")
            {
                Session["EmpId"] = "Admin";
                Session["Pwd"] = "Admin123";
                Session["UserType"] = "Admin";
                Response.Redirect("Home.aspx");
            }
            else
            {
                da = new SqlDataAdapter("Select EmpID,Password,UserType from RegisterUser where EmpID ='" + txtuserlogin.Text + "' and Password='" + txtpassword.Text + "'", cn);
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    Session["EmpId"] = dt.Rows[0]["EmpId"].ToString();
                    Session["Password"] = dt.Rows[0]["Password"].ToString();
                    Session["UserType"] = dt.Rows[0]["UserType"].ToString();


                    if (Session["UserType"].ToString() == "Manager")
                    {

                        Response.Redirect("Home.aspx");

                    }
                    else
                    {
                        Response.Redirect("Home.aspx");

                    }
                    cn.Close();
                    cmd.Dispose();
                }
                else
                {
                    Response.Write("Login Fail");

                }





            }
        }
    }
}